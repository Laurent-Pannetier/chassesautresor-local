<?php

// File generated from our OpenAPI spec
namespace WPForms\Vendor\Stripe\Util;

class ApiVersion
{
    const CURRENT = '2025-01-27.acacia';
}
