<?php

namespace WPMailSMTP\Vendor\GuzzleHttp\Exception;

/**
 * Exception when a server error is encountered (5xx codes)
 */
class ServerException extends \WPMailSMTP\Vendor\GuzzleHttp\Exception\BadResponseException
{
}
