<?php

namespace WPMailSMTP\Vendor;

return array(0 => \true, 1 => \true, 2 => \true, 3 => \true, 4 => \true, 5 => \true, 6 => \true, 7 => \true, 8 => \true, 9 => \true, 10 => \true, 11 => \true, 12 => \true, 13 => \true, 14 => \true, 15 => \true, 16 => \true, 17 => \true, 18 => \true, 19 => \true, 20 => \true, 21 => \true, 22 => \true, 23 => \true, 24 => \true, 25 => \true, 26 => \true, 27 => \true, 28 => \true, 29 => \true, 30 => \true, 31 => \true, 32 => \true, 33 => \true, 34 => \true, 35 => \true, 36 => \true, 37 => \true, 38 => \true, 39 => \true, 40 => \true, 41 => \true, 42 => \true, 43 => \true, 44 => \true, 47 => \true, 58 => \true, 59 => \true, 60 => \true, 61 => \true, 62 => \true, 63 => \true, 64 => \true, 91 => \true, 92 => \true, 93 => \true, 94 => \true, 95 => \true, 96 => \true, 123 => \true, 124 => \true, 125 => \true, 126 => \true, 127 => \true, 8800 => \true, 8814 => \true, 8815 => \true);
