export enum ModalName {
  XmlSecurityModal = "XmlSecurityModal",
  ByPassLinkResetModal = "ByPassLinkResetModal",
  EnableLlmsTxtModal = "EnableLlmsTxtModal",
}
