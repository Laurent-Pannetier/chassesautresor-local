<?php
return [
	'Imagify\User\ServiceProvider',
	'Imagify\Admin\ServiceProvider',
	'Imagify\Avif\ServiceProvider',
	'Imagify\CDN\ServiceProvider',
	'Imagify\Picture\ServiceProvider',
	'Imagify\Stats\ServiceProvider',
	'Imagify\Webp\ServiceProvider',
	'Imagify\ThirdParty\ServiceProvider',
	'Imagify\Media\ServiceProvider',
];
